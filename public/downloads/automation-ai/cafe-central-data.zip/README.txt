Cafe Central practice data
==========================

cafe_central_sales.csv      One month of sales (semicolon-separated, UTF-8).
cafe_central_customers.json Customer list (has comment lines, so it is not strict JSON).

Keep these files exactly as downloaded. Do not open the CSV in Excel and save it:
Excel can change dates and amounts without telling you. Make a copy if you want to
experiment.

Course: https://learn.dompe.space/
