Cafe Central office documents
=============================

cafe_central_monthly_summary.xlsx  A monthly summary by shop, with merged headers.
cafe_central_invoice.pdf           A supplier invoice. Its table is not a real table.

Keep these files exactly as downloaded. Make a copy if you want to experiment.

Course: https://learn.dompe.space/
